from __future__ import annotations

from ctypes import CDLL
from importlib import resources
from pathlib import Path
from typing import Union


def _load_shared_library() -> CDLL:
    """Load the bundled extract_mvs shared object from the installed package."""
    try:
        so_path = resources.files(__package__).joinpath("extract_mvs.so")
    except (AttributeError, ImportError):
        raise RuntimeError("Unable to locate extract_mvs.so in mv_tractus package resources")

    if not so_path.exists():
        raise FileNotFoundError(f"Shared library not found at {so_path}")

    return CDLL(str(so_path))


_emv = _load_shared_library()


class MVTractus:
    """Thin Python wrapper around the MV-Tractus FFmpeg shared library."""

    def __init__(self, videopath: Union[str, Path], output_dir: Union[str, Path] = "./output/mv") -> None:
        self.videopath = Path(videopath)
        self.output_dir = Path(output_dir)
        self._ensure_output_dir()

    def get_motion_vectors(self) -> None:
        """Extract motion vectors for the configured video path."""
        _emv.extract_motion_vectors(str(self.videopath).encode())

    def _ensure_output_dir(self) -> None:
        """Ensure the expected output directory exists on disk."""
        self.output_dir.mkdir(parents=True, exist_ok=True)


__all__ = ["MVTractus"]
