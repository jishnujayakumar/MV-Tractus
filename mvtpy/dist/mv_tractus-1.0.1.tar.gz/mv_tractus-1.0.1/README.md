# MV-Tractus
A simple tool for motion vector extraction from mpeg videos.

## Python usage

```bash
pip install mv-tractus
```

```python
from mv_tractus import MVTractus

mvt = MVTractus("/path/to/video.mp4")  # outputs to ./output/mv by default
mvt.get_motion_vectors()
```

## If you use this tool, please cite.

> @misc{j_padalunkal_2018_216985,  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;author = {J. Padalunkal},  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;title = {MV-Tractus},  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;month = apr,  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;year = 2018,  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;doi = {10.5072/zenodo.216985},  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;url = {https://doi.org/10.5072/zenodo.216985}
}

### [![DOI](https://sandbox.zenodo.org/badge/DOI/10.5072/zenodo.216985.svg)](https://doi.org/10.5072/zenodo.216985)
